import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores Product instances and supports lookup and listing.
 */
public class Catalog {
    private Map<String, Product> products = new HashMap<>();

    public Catalog() {}

    public void addProduct(Product p) {
        if (p == null || p.getId() == null) return;
        products.put(p.getId(), p);
    }

    public Collection<Product> listProducts() {
        return products.values();
    }

    public Product findProductById(String id) {
        return products.get(id);
    }

    public int size() { return products.size(); }
}

