import java.util.*;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        AccountManager am = new AccountManager();
        Catalog catalog = new Catalog();
        OrderManager om = new OrderManager();
        Bank bank = new Bank();

        preloadCatalog(catalog);

        Customer logged = null;
        Cart cart = new Cart();

        boolean run = true;
        while (run) {
            printMenu(logged);
            String c = sc.nextLine().trim();

            switch (c) {
                case "1": createAccountFlow(am); break;
                case "2": logged = loginFlow(am); cart = new Cart(); break;
                case "3": showCatalog(catalog); break;
                case "4": selectItemsFlow(catalog, cart); break;
                case "5":
                    if (logged == null) System.out.println("Login first.");
                    else placeOrderFlow(logged, cart, om, bank);
                    break;
                case "6":
                    if (logged == null) System.out.println("Login first.");
                    else viewOrdersFlow(logged, om);
                    break;
                case "7":
                    if (logged != null) System.out.println("Logged out.");
                    logged = null;
                    cart = new Cart();
                    break;
                case "8": run = false; break;
                default: System.out.println("Invalid.");
            }
        }
        System.out.println("Goodbye.");
    }

    private static void printMenu(Customer logged) {
        System.out.println("\n1. Create Account");
        System.out.println("2. Log In");
        System.out.println("3. Browse Catalog");
        System.out.println("4. Select Items");
        System.out.println("5. Make Order");
        System.out.println("6. View Orders");
        System.out.println("7. Log Out");
        System.out.println("8. Exit");
        if (logged != null)
            System.out.println("Logged in as: " + logged.getName());
        System.out.print("Choose: ");
    }

    private static void createAccountFlow(AccountManager am) {
        System.out.println("\n=== CREATE ACCOUNT ===");

        // Show password rules to the user
        System.out.println("Password Requirements:");
        System.out.println(" - At least 6 characters long");
        System.out.println(" - Must include at least one uppercase letter (A–Z)");
        System.out.println(" - Must include at least one number (0–9)");
        System.out.println(" - Must include at least one special character: @ # $ % & *");
        System.out.println();

        System.out.print("ID: ");
        String id = sc.nextLine();

        if (am.findCustomer(id) != null) {
            System.out.println("That ID already exists. Please try another.");
            return;
        }

        System.out.print("Password: ");
        String pw = sc.nextLine();

        if (!AccountManager.isPasswordValid(pw)) {
            System.out.println("Password does not meet the requirements. Please try again.");
            return;
        }

        System.out.print("Name: ");
        String name = sc.nextLine();

        System.out.print("Address: ");
        String addr = sc.nextLine();

        System.out.print("Credit Card #: ");
        String cc = sc.nextLine();

        System.out.println("\nChoose a security question:");
        SecurityQuestion[] qs = SecurityQuestion.values();
        for (int i = 0; i < qs.length; i++) {
            System.out.println((i + 1) + ") " + qs[i]);
        }

        System.out.print("Choice: ");
        int q = Integer.parseInt(sc.nextLine());
        SecurityQuestion chosen = qs[q - 1];

        System.out.print("Answer: ");
        String ans = sc.nextLine();

        boolean ok = am.createAccount(id, pw, name, addr, cc, chosen, ans);
        System.out.println(ok ? "Account created successfully!" : "Failed to create account.");
    }


    private static Customer loginFlow(AccountManager am) {
        System.out.println("\n=== LOGIN ===");

        System.out.print("ID: ");
        String id = sc.nextLine();

        Customer c = am.findCustomer(id);
        if (c == null) {
            System.out.println("Not found.");
            return null;
        }

        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Password: ");
            String pw = sc.nextLine();
            if (c.validatePassword(pw)) {
                System.out.println("Security Question: " + c.getSecurityQuestion());
                System.out.print("Answer: ");
                if (c.checkSecurityAnswer(sc.nextLine())) {
                    System.out.println("Welcome " + c.getName());
                    return c;
                }
                System.out.println("Wrong answer. Login aborted.");
                return null;
            }
            attempts++;
            System.out.println("Wrong password.");
        }
        System.out.println("Too many attempts.");
        return null;
    }

    private static void showCatalog(Catalog cat) {
        System.out.println("\n=== CATALOG ===");
        for (Product p : cat.listProducts()) {
            System.out.println(p);
        }
    }

    private static void selectItemsFlow(Catalog cat, Cart cart) {
        System.out.println("\n=== ADD ITEMS ===");
        showCatalog(cat);

        while (true) {
            System.out.print("Product ID (or done): ");
            String pid = sc.nextLine();
            if (pid.equalsIgnoreCase("done")) break;

            Product p = cat.findProductById(pid);
            if (p == null) {
                System.out.println("Not found.");
                continue;
            }

            System.out.print("Quantity: ");
            int q = Integer.parseInt(sc.nextLine());
            cart.addItem(p, q);
            System.out.println("Added. Subtotal: $" + cart.getSubtotal());
        }
    }

    private static void placeOrderFlow(Customer cust, Cart cart, OrderManager om, Bank bank) {
        if (cart.getCartItems().isEmpty()) {
            System.out.println("Cart empty.");
            return;
        }

        System.out.println("Delivery: 1) MAIL (+$3)  2) PICKUP");
        String d = sc.nextLine();
        String method = d.equals("1") ? "MAIL" : "PICKUP";

        Order o = om.placeOrder(cust, cart, method, bank);
        if (o == null) {
            System.out.println("Payment denied.");
            return;
        }

        System.out.println("Order placed!");
        System.out.println("Authorization: " + o.getAuthorizationNumber());
        cart.clear();
    }

    private static void viewOrdersFlow(Customer cust, OrderManager om) {
        List<Order> list = om.viewOrders(cust.getId());
        if (list.isEmpty()) {
            System.out.println("No orders.");
            return;
        }

        for (Order o : list) {
            System.out.println("Order " + o.getOrderId());
            for (String pid : o.getProductQuantities().keySet()) {
                System.out.println("  " + pid + " x" + o.getProductQuantities().get(pid));
            }
            System.out.println("Total: $" + o.getTotal());
            System.out.println("Auth: " + o.getAuthorizationNumber());
            System.out.println("---");
        }
    }

    private static void preloadCatalog(Catalog cat) {
        cat.addProduct(new Product("P001", "Laptop", "15” Laptop", 999.99, 899.99));
        cat.addProduct(new Product("P002", "Mouse", "Wireless Mouse", 29.99, null));
        cat.addProduct(new Product("P003", "Headphones", "Noise Cancelling", 149.99, 119.99));
        cat.addProduct(new Product("P004", "Cable", "USB-C Cable", 9.99, null));
    }
}
