import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Manages order placement and order storage.
 */
public class OrderManager {
    private List<Order> orders = new ArrayList<>();
    private static final double MAILING_FEE = 3.00;

    public OrderManager() {}

    /**
     * Place order: charges card via Bank and stores order if authorized.
     * Returns Order on success, or null if payment denied or invalid input.
     */
    public Order placeOrder(Customer customer, Cart cart, String deliveryMethod, Bank bank) {
        if (customer == null || cart == null || bank == null) return null;
        double subtotal = cart.getSubtotal();
        double total = subtotal;
        if ("MAIL".equalsIgnoreCase(deliveryMethod)) total += MAILING_FEE;

        String card = customer.getCreditCardNumber();
        if (card == null) return null;

        Optional<String> auth = bank.chargeCard(card, total);
        if (!auth.isPresent()) {
            return null; // payment denied
        }

        String orderId = UUID.randomUUID().toString();
        Order order = new Order(orderId, new Date(), customer.getId(), cart.getItems(), total, auth.get(), deliveryMethod);
        orders.add(order);
        return order;
    }

    public List<Order> viewOrders(String customerId) {
        List<Order> results = new ArrayList<>();
        for (Order o : orders) {
            if (o.getCustomerId().equals(customerId)) results.add(o);
        }
        return results;
    }
}
