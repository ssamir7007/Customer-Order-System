import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.Map;

/**
 * MainGUI - Swing front-end for the Customer Order System (Part 3)
 */
public class MainGUI extends JFrame {

    // Backend
    private final AccountManager accountManager = new AccountManager();
    private final Catalog catalog = new Catalog();
    private final OrderManager orderManager = new OrderManager();
    private final Bank bank = new Bank();

    // Runtime state
    private Customer loggedIn = null;
    private Cart cart = new Cart();

    // Swing
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel cards = new JPanel(cardLayout);
    private final JLabel statusBar = new JLabel("Welcome to COS GUI Demo");

    // Components reused across panels
    private JList<Product> productJList;
    private DefaultListModel<Product> productListModel;
    private JTextArea cartArea;
    private JTextArea ordersArea;

    public MainGUI() {
        super("Customer Order System - GUI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        preloadCatalog();    // preload sample products
        initUI();

        setVisible(true);
    }

    private void preloadCatalog() {
        catalog.addProduct(new Product("P001", "Laptop", "15-inch laptop, 16GB RAM", 999.99, 899.99));
        catalog.addProduct(new Product("P002", "Wireless Mouse", "Ergonomic wireless mouse", 29.99, null));
        catalog.addProduct(new Product("P003", "Headphones", "Noise-cancelling headphones", 149.99, 119.99));
        catalog.addProduct(new Product("P004", "USB-C Cable", "1m charging cable", 9.99, null));
    }

    private void initUI() {
        setLayout(new BorderLayout());
        add(buildTopToolbar(), BorderLayout.NORTH);
        add(cards, BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);

        // builds card panels
        cards.add(buildHomePanel(), "HOME");
        cards.add(buildCreateAccountPanel(), "CREATE");
        cards.add(buildLoginPanel(), "LOGIN");
        cards.add(buildCatalogPanel(), "CATALOG");
        cards.add(buildCartPanel(), "CART");
        cards.add(buildCheckoutPanel(), "CHECKOUT");
        cards.add(buildOrdersPanel(), "ORDERS");

        showCard("HOME");
    }

    private JPanel buildTopToolbar() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton home = new JButton("Home");
        JButton create = new JButton("Create Account");
        JButton login = new JButton("Log In");
        JButton catalogBtn = new JButton("Catalog");
        JButton cartBtn = new JButton("Cart");
        JButton ordersBtn = new JButton("My Orders");
        JButton logout = new JButton("Log Out");

        home.addActionListener(e -> showCard("HOME"));
        create.addActionListener(e -> showCard("CREATE"));
        login.addActionListener(e -> showCard("LOGIN"));
        catalogBtn.addActionListener(e -> showCard("CATALOG"));
        cartBtn.addActionListener(e -> {
            updateCartArea();
            showCard("CART");
        });
        ordersBtn.addActionListener(e -> {
            if (requireLogin()) {
                updateOrdersArea();
                showCard("ORDERS");
            }
        });
        logout.addActionListener(e -> {
            if (loggedIn != null) {
                loggedIn = null;
                cart = new Cart();
                updateCartArea();
                setStatus("Logged out.");
            } else {
                setStatus("No user is currently logged in.");
            }
            showCard("HOME");
        });

        p.add(home);
        p.add(create);
        p.add(login);
        p.add(catalogBtn);
        p.add(cartBtn);
        p.add(ordersBtn);
        p.add(logout);
        return p;
    }

    private JPanel buildStatusBar() {
        JPanel p = new JPanel(new BorderLayout());
        statusBar.setBorder(new EmptyBorder(6, 8, 6, 8));
        p.add(statusBar, BorderLayout.CENTER);
        return p;
    }

    private JPanel buildHomePanel() {
        JPanel p = new JPanel(new BorderLayout());
        JLabel title = new JLabel("<html><h1>Customer Order System (GUI Demo)</h1></html>", SwingConstants.CENTER);
        JTextArea info = new JTextArea();
        info.setEditable(false);
        info.setLineWrap(true);
        info.setWrapStyleWord(true);
        info.setText("Use the top menu to create an account, log in, browse the catalog, add items to the cart, place orders, and view past orders. The Bank simulator randomly denies ~5% of transactions to simulate declines.");
        info.setBorder(new EmptyBorder(10, 10, 10, 10));
        p.add(title, BorderLayout.NORTH);
        p.add(info, BorderLayout.CENTER);
        return p;
    }

    private JPanel buildCreateAccountPanel() {
        JPanel p = new JPanel(new BorderLayout());
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;

        // Password rules
        JPanel rules = new JPanel(new GridLayout(0, 1));
        rules.setBorder(BorderFactory.createTitledBorder("Password Requirements"));
        rules.add(new JLabel("• At least 6 characters long"));
        rules.add(new JLabel("• At least one UPPERCASE letter (A-Z)"));
        rules.add(new JLabel("• At least one number (0-9)"));
        rules.add(new JLabel("• At least one special character: @ # $ % & *"));
        p.add(rules, BorderLayout.NORTH);

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("ID:"), gbc);
        JTextField idField = new JTextField(20);
        gbc.gridx = 1;
        form.add(idField, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Password:"), gbc);
        JPasswordField pwField = new JPasswordField(20);
        gbc.gridx = 1;
        form.add(pwField, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Full Name:"), gbc);
        JTextField nameField = new JTextField(20);
        gbc.gridx = 1;
        form.add(nameField, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Address:"), gbc);
        JTextField addrField = new JTextField(20);
        gbc.gridx = 1;
        form.add(addrField, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Credit Card #:"), gbc);
        JTextField cardField = new JTextField(20);
        gbc.gridx = 1;
        form.add(cardField, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Security Question:"), gbc);
        JComboBox<SecurityQuestion> sqBox = new JComboBox<>(SecurityQuestion.values());
        gbc.gridx = 1;
        form.add(sqBox, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        form.add(new JLabel("Answer:"), gbc);
        JTextField ansField = new JTextField(20);
        gbc.gridx = 1;
        form.add(ansField, gbc);
        y++;

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton createBtn = new JButton("Create Account");
        JButton clearBtn = new JButton("Clear");
        buttons.add(clearBtn);
        buttons.add(createBtn);

        clearBtn.addActionListener(e -> {
            idField.setText("");
            pwField.setText("");
            nameField.setText("");
            addrField.setText("");
            cardField.setText("");
            sqBox.setSelectedIndex(0);
            ansField.setText("");
        });

        createBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String pw = new String(pwField.getPassword());
            String name = nameField.getText().trim();
            String addr = addrField.getText().trim();
            String cc = cardField.getText().trim();
            SecurityQuestion q = (SecurityQuestion) sqBox.getSelectedItem();
            String ans = ansField.getText().trim();

            if (id.isEmpty() || pw.isEmpty() || name.isEmpty() || addr.isEmpty() || cc.isEmpty() || ans.isEmpty()) {
                setStatus("Please fill all fields.");
                return;
            }
            if (accountManager.findCustomer(id) != null) {
                setStatus("ID already exists. Choose another.");
                return;
            }
            if (!AccountManager.isPasswordValid(pw)) {
                setStatus("Password does not meet requirements.");
                return;
            }
            boolean ok = accountManager.createAccount(id, pw, name, addr, cc, q, ans);
            if (ok) {
                setStatus("Account created. You may now log in.");
                // clear fields
                clearBtn.doClick();
                showCard("LOGIN");
            } else {
                setStatus("Failed to create account (check inputs).");
            }
        });

        p.add(form, BorderLayout.CENTER);
        p.add(buttons, BorderLayout.SOUTH);
        return p;
    }

    private JPanel buildLoginPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        p.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        JTextField idField = new JTextField(20);
        p.add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        p.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        JPasswordField pwField = new JPasswordField(20);
        p.add(pwField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        JButton loginBtn = new JButton("Log In");
        JButton backBtn = new JButton("Back");
        p.add(backBtn, gbc);
        gbc.gridx = 1;
        p.add(loginBtn, gbc);

        final int[] attempts = {0};
        loginBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            String pw = new String(pwField.getPassword());
            Customer c = accountManager.findCustomer(id);
            if (c == null) {
                setStatus("No account found with that ID.");
                return;
            }
            if (c.validatePassword(pw)) {
                // asks security question
                String question = c.getSecurityQuestion().name().replace('_', ' ');
                String answer = JOptionPane.showInputDialog(this, "Security question: " + question, "Security Question", JOptionPane.QUESTION_MESSAGE);
                if (answer != null && c.checkSecurityAnswer(answer)) {
                    loggedIn = c;
                    cart = new Cart(); // fresh cart on login
                    setStatus("Logged in as " + c.getName());
                    attempts[0] = 0;
                    showCard("CATALOG");
                } else {
                    setStatus("Security answer incorrect. Login failed.");
                }
            } else {
                attempts[0]++;
                if (attempts[0] >= 3) {
                    attempts[0] = 0;
                    setStatus("Maximum password attempts reached.");
                    showCard("HOME");
                } else {
                    setStatus("Incorrect password. Attempts left: " + (3 - attempts[0]));
                }
            }
        });

        backBtn.addActionListener(e -> showCard("HOME"));
        return p;
    }

    private JPanel buildCatalogPanel() {
        JPanel p = new JPanel(new BorderLayout());
        productListModel = new DefaultListModel<>();
        for (Product prod : catalog.listProducts()) productListModel.addElement(prod);

        productJList = new JList<>(productListModel);
        productJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(productJList);

        JPanel right = new JPanel();
        right.setLayout(new BoxLayout(right, BoxLayout.Y_AXIS));
        right.setBorder(new EmptyBorder(10, 10, 10, 10));
        right.add(new JLabel("Quantity:"));
        JSpinner qtySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        right.add(qtySpinner);
        right.add(Box.createVerticalStrut(10));
        JButton addBtn = new JButton("Add To Cart");
        right.add(addBtn);
        right.add(Box.createVerticalGlue());
        JButton back = new JButton("Back");
        right.add(back);

        addBtn.addActionListener(e -> {
            Product sel = productJList.getSelectedValue();
            if (sel == null) {
                setStatus("Select a product first.");
                return;
            }
            int qty = (Integer) qtySpinner.getValue();
            cart.addItem(sel, qty);
            setStatus("Added " + qty + " x " + sel.getName() + " to cart. Subtotal: $" + String.format("%.2f", cart.getSubtotal()));
        });

        back.addActionListener(e -> showCard("HOME"));

        p.add(new JLabel("Catalog", SwingConstants.CENTER), BorderLayout.NORTH);
        p.add(scroll, BorderLayout.CENTER);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private JPanel buildCartPanel() {
        JPanel p = new JPanel(new BorderLayout());
        cartArea = new JTextArea();
        cartArea.setEditable(false);
        JScrollPane sp = new JScrollPane(cartArea);

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton checkout = new JButton("Checkout");
        JButton remove = new JButton("Remove Selected");
        JButton back = new JButton("Back");

        bottom.add(remove);
        bottom.add(checkout);
        bottom.add(back);

        // Remove: removes the selected product ID typed by user
        remove.addActionListener(e -> {
            String pid = JOptionPane.showInputDialog(this, "Enter product ID to remove from cart:");
            if (pid != null && !pid.trim().isEmpty()) {
                boolean ok = cart.removeItem(pid.trim());
                if (ok) setStatus("Removed product " + pid);
                else setStatus("Product not found in cart.");
                updateCartArea();
            }
        });

        checkout.addActionListener(e -> {
            if (!requireLogin()) return;
            showCard("CHECKOUT");
        });

        back.addActionListener(e -> showCard("HOME"));

        p.add(new JLabel("Your Cart", SwingConstants.CENTER), BorderLayout.NORTH);
        p.add(sp, BorderLayout.CENTER);
        p.add(bottom, BorderLayout.SOUTH);

        // populate area when shown
        p.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                updateCartArea();
            }
        });

        return p;
    }

    private JPanel buildCheckoutPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        p.add(new JLabel("Delivery Method:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> delivery = new JComboBox<>(new String[]{"MAIL (+$3.00)", "PICKUP (free)"});
        p.add(delivery, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        p.add(new JLabel("Order Total:"), gbc);
        gbc.gridx = 1;
        JLabel totalLabel = new JLabel("$0.00");
        p.add(totalLabel, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        p.add(new JLabel("Stored card (masked):"), gbc);
        gbc.gridx = 1;
        JLabel storedCard = new JLabel("<none>");
        p.add(storedCard, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        p.add(new JLabel("Or enter new card:"), gbc);
        gbc.gridx = 1;
        JTextField newCardField = new JTextField(16);
        p.add(newCardField, gbc);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton place = new JButton("Place Order");
        JButton back = new JButton("Back");
        btns.add(back);
        btns.add(place);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        p.add(btns, gbc);

        // when shown, updates totals & stored card
        p.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                double subtotal = cart.getSubtotal();
                boolean mail = delivery.getSelectedIndex() == 0;
                double total = subtotal + (mail ? 3.0 : 0.0);
                totalLabel.setText(String.format("$%.2f", total));
                storedCard.setText(loggedIn != null && loggedIn.getCreditCardNumber() != null ? maskCard(loggedIn.getCreditCardNumber()) : "<none>");
            }
        });

        place.addActionListener(e -> {
            if (cart.getCartItems().isEmpty()) {
                setStatus("Cart is empty. Add items before placing an order.");
                return;
            }
            String method = delivery.getSelectedIndex() == 0 ? "MAIL" : "PICKUP";
            double subtotal = cart.getSubtotal();
            double total = subtotal + (method.equals("MAIL") ? 3.0 : 0.0);

            String cardToUse = newCardField.getText().trim();
            if (cardToUse.isEmpty()) {
                if (loggedIn.getCreditCardNumber() == null || loggedIn.getCreditCardNumber().trim().isEmpty()) {
                    setStatus("No card available. Enter a card or update your account.");
                    return;
                }
                cardToUse = loggedIn.getCreditCardNumber();
            }

            // Trys charging via bank directly so we can prompt user to retry with a new card if denied
            java.util.Optional<String> authMaybe = bank.chargeCard(cardToUse, total);
            if (!authMaybe.isPresent()) {
                int res = JOptionPane.showConfirmDialog(this, "Payment was denied. Would you like to enter a different card?", "Payment Denied", JOptionPane.YES_NO_OPTION);
                if (res == JOptionPane.YES_OPTION) {
                    // allows user to enter another card in the newCardField and try again (user must press Place Order again)
                    setStatus("Enter a new card in the field and press Place Order again.");
                } else {
                    setStatus("Order canceled.");
                }
                return;
            }

            // Bank approved. Now places an order via OrderManager (which will also call bank internally in our Part2 code).
            Order order = orderManager.placeOrder(loggedIn, cart, method, bank);
            if (order != null) {
                // If the card used was different from stored, updates stored card per requirement
                if (!cardToUse.equals(loggedIn.getCreditCardNumber())) {
                    loggedIn.setCreditCardNumber(cardToUse);
                }
                setStatus("Order placed! Auth #: " + order.getAuthorizationNumber());
                cart.clear();
                updateCartArea();
                updateOrdersArea();
                showCard("ORDERS");
            } else {
                setStatus("Order placement failed.");
            }
        });

        back.addActionListener(e -> showCard("CART"));
        return p;
    }

    private JPanel buildOrdersPanel() {
        JPanel p = new JPanel(new BorderLayout());
        ordersArea = new JTextArea();
        ordersArea.setEditable(false);
        JScrollPane sp = new JScrollPane(ordersArea);
        JButton back = new JButton("Back");
        back.addActionListener(e -> showCard("HOME"));
        p.add(new JLabel("Order History", SwingConstants.CENTER), BorderLayout.NORTH);
        p.add(sp, BorderLayout.CENTER);
        p.add(back, BorderLayout.SOUTH);

        p.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                updateOrdersArea();
            }
        });

        return p;
    }

    private void updateCartArea() {
        StringBuilder sb = new StringBuilder();
        if (cart.getCartItems().isEmpty()) {
            sb.append("Cart is empty.\n");
        } else {
            for (CartItem ci : cart.getCartItems()) {
                Product p = ci.getProduct();
                sb.append(String.format("%s  | %s  | qty: %d  | unit: $%.2f  | total: $%.2f%n",
                        p.getId(), p.getName(), ci.getQuantity(), p.getEffectivePrice(), p.getEffectivePrice() * ci.getQuantity()));
            }
            sb.append(String.format("%nSubtotal: $%.2f%n", cart.getSubtotal()));
        }
        cartArea.setText(sb.toString());
    }

    private void updateOrdersArea() {
        if (loggedIn == null) {
            ordersArea.setText("Please log in to view orders.");
            return;
        }
        StringBuilder sb = new StringBuilder();
        java.util.List<Order> orders = orderManager.viewOrders(loggedIn.getId());
        if (orders.isEmpty()) {
            sb.append("No orders found.\n");
        } else {
            for (Order o : orders) {
                sb.append(String.format("Order ID: %s%nDate: %s%nTotal: $%.2f%nAuth: %s%nItems:%n",
                        o.getOrderId(), o.getOrderDate(), o.getTotal(), o.getAuthorizationNumber()));
                for (Map.Entry<String, Integer> e : o.getProductQuantities().entrySet()) {
                    Product p = catalog.findProductById(e.getKey());
                    String pname = p != null ? p.getName() : e.getKey();
                    sb.append(String.format("  - %s (x%d)%n", pname, e.getValue()));
                }
                sb.append("\n---\n\n");
            }
        }
        ordersArea.setText(sb.toString());
    }

    private boolean requireLogin() {
        if (loggedIn == null) {
            int r = JOptionPane.showConfirmDialog(this, "You must be logged in to do that. Go to login screen?", "Login required", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) showCard("LOGIN");
            return false;
        }
        return true;
    }

    private void showCard(String name) {
        if ("CART".equals(name)) updateCartArea();
        if ("CHECKOUT".equals(name)) {
            // nothing extra; componentShown for that panel will update totals
        }
        if ("ORDERS".equals(name)) updateOrdersArea();
        cardLayout.show(cards, name);
    }

    private void setStatus(String msg) {
        statusBar.setText(msg);
    }

    private String maskCard(String cc) {
        if (cc == null) return "<none>";
        String digits = cc.replaceAll("[^0-9]", "");
        if (digits.length() <= 4) return digits;
        return "**** **** **** " + digits.substring(digits.length() - 4);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainGUI::new);
    }
}
