import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Shopping cart that keeps CartItems.
 */
public class Cart {
    private List<CartItem> items = new ArrayList<>();

    public Cart() {}

    public void addItem(Product p, int quantity) {
        if (p == null || quantity <= 0) return;
        for (CartItem ci : items) {
            if (ci.getProduct().getId().equals(p.getId())) {
                ci.setQuantity(ci.getQuantity() + quantity);
                return;
            }
        }
        items.add(new CartItem(p, quantity));
    }

    public boolean removeItem(String productId) {
        return items.removeIf(ci -> ci.getProduct().getId().equals(productId));
    }

    public double getSubtotal() {
        double s = 0.0;
        for (CartItem ci : items) {
            s += ci.getProduct().getEffectivePrice() * ci.getQuantity();
        }
        return s;
    }

    public Map<String, Integer> getItems() {
        Map<String, Integer> map = new HashMap<>();
        for (CartItem ci : items) {
            map.put(ci.getProduct().getId(), ci.getQuantity());
        }
        return map;
    }

    public List<CartItem> getCartItems() { return items; }

    public void clear() { items.clear(); }
}
