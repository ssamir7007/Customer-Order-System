/**
 * A CartItem associates a Product and a quantity for the shopping cart.
 */
public class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = Math.max(1, quantity);
    }

    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int q) { this.quantity = Math.max(1, q); }

    @Override
    public String toString() {
        return product.getName() + " x" + quantity + " - $" + String.format("%.2f", product.getEffectivePrice() * quantity);
    }
}
