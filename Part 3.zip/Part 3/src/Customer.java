import java.util.Objects;

/**
 * Represents a customer account in the Customer Order System.
 * Stores authentication info, profile, credit card, and security question.
 */
public class Customer {
    private String id;
    private String password;
    private String name;
    private String address;
    private String creditCardNumber;
    private SecurityQuestion securityQuestion;
    private String securityAnswer;

    /**
     * Constructor for Customer.
     */
    public Customer(String id, String password, String name, String address,
                    String creditCardNumber, SecurityQuestion question, String answer) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.address = address;
        this.creditCardNumber = creditCardNumber;
        this.securityQuestion = question;
        this.securityAnswer = (answer == null ? null : answer.trim());
    }

    /**
     * Exact-match password check.
     */
    public boolean validatePassword(String attempt) {
        return Objects.equals(password, attempt);
    }

    /**
     * Security question answer check (case-insensitive).
     */
    public boolean checkSecurityAnswer(String attempt) {
        if (securityAnswer == null || attempt == null) return false;
        return securityAnswer.equalsIgnoreCase(attempt.trim());
    }

    // Getters & setters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getCreditCardNumber() { return creditCardNumber; }
    public SecurityQuestion getSecurityQuestion() { return securityQuestion; }

    public void setPassword(String password) { this.password = password; }
    public void setCreditCardNumber(String creditCardNumber) { this.creditCardNumber = creditCardNumber; }

    @Override
    public String toString() {
        return "Customer{id='" + id + "', name='" + name + "'}";
    }
}
