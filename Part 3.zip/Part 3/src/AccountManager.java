import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Manages customer accounts: creation, lookup, login, logout.
 * Uses an in-memory map for Part 2.
 */
public class AccountManager {
    private Map<String, Customer> customers = new HashMap<>();

    // Password rules: at least 6 chars, 1 digit, 1 special (@#$%&*), 1 uppercase
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[0-9])(?=.*[@#$%&*])(?=.*[A-Z]).{6,}$");

    public AccountManager() {
        // empty constructor
    }

    /**
     * Creates an account from a prepared Customer object.
     * Returns false if id exists or required fields are missing.
     */
    public boolean createAccount(Customer c) {
        if (c == null) return false;
        String id = c.getId();
        if (id == null || id.trim().isEmpty()) return false;
        if (customers.containsKey(id)) return false;
        if (c.getName() == null || c.getAddress() == null || c.getCreditCardNumber() == null) return false;
        customers.put(id, c);
        return true;
    }

    /**
     * Convenience method to create by fields with password validation enforced.
     */
    public boolean createAccount(String id, String password, String name, String address,
                                 String creditCardNumber, SecurityQuestion question, String answer) {
        if (id == null || id.trim().isEmpty()) return false;
        if (customers.containsKey(id)) return false;
        if (!isPasswordValid(password)) return false;
        if (name == null || address == null || creditCardNumber == null) return false;
        Customer c = new Customer(id, password, name, address, creditCardNumber, question, answer);
        customers.put(id, c);
        return true;
    }

    /**
     * Simple login: returns Customer on success, or null on failure (non-existent or wrong password).
     */
    public Customer login(String id, String password) {
        if (id == null || password == null) return null;
        Customer c = customers.get(id);
        if (c == null) return null;
        if (c.validatePassword(password)) return c;
        return null;
    }

    /**
     * Logout placeholder (no session maintained in Part 2).
     */
    public void logout(Customer c) {
        // No stateful sessions in this project
    }

    public Customer findCustomer(String id) {
        return customers.get(id);
    }

    /**
     * Checks if password meets project rules.
     */
    public static boolean isPasswordValid(String pwd) {
        if (pwd == null) return false;
        return PASSWORD_PATTERN.matcher(pwd).matches();
    }

    public int totalAccounts() {
        return customers.size();
    }
}
