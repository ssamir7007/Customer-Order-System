import java.util.Optional;
import java.util.Random;

/**
 * Simulates a bank service to charge credit cards.
 * For this project, a card is valid if it has 12-19 digits.
 * Bank randomly denies some transactions (simulating declines).
 */
public class Bank {
    private Random random = new Random();

    public Bank() {}

    /**
     * Trys to charge cardNumber for amount. Returns Optional authorization code on success.
     */
    public Optional<String> chargeCard(String cardNumber, double amount) {
        if (cardNumber == null) return Optional.empty();
        String digitsOnly = cardNumber.replaceAll("[^0-9]", "");
        if (digitsOnly.length() < 12 || digitsOnly.length() > 19) return Optional.empty();
        // simulates occasional decline (5% failure)
        if (random.nextInt(20) == 0) return Optional.empty();
        int code = 1000 + random.nextInt(9000);
        return Optional.of(String.format("%04d", code));
    }
}
