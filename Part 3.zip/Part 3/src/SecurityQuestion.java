/**
 * Simple enum for security questions used during account creation.
 */
public enum SecurityQuestion {
    MOTHERS_MAIDEN_NAME,
    FIRST_PET,
    FAVORITE_TEACHER,
    BIRTH_CITY,
    FAVORITE_COLOR
}
