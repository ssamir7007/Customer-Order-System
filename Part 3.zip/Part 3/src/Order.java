import java.util.Date;
import java.util.Map;

/**
 * Order represents a placed customer order.
 */
public class Order {
    private String orderId;
    private Date orderDate;
    private String customerId;
    private Map<String, Integer> productQuantities;
    private double total;
    private String authorizationNumber;
    private String deliveryMethod;

    public Order(String orderId, Date orderDate, String customerId,
                 Map<String, Integer> productQuantities, double total,
                 String authorizationNumber, String deliveryMethod) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.customerId = customerId;
        this.productQuantities = productQuantities;
        this.total = total;
        this.authorizationNumber = authorizationNumber;
        this.deliveryMethod = deliveryMethod;
    }

    public String getOrderId() { return orderId; }
    public Date getOrderDate() { return orderDate; }
    public String getCustomerId() { return customerId; }
    public Map<String, Integer> getProductQuantities() { return productQuantities; }
    public double getTotal() { return total; }
    public String getAuthorizationNumber() { return authorizationNumber; }
    public String getDeliveryMethod() { return deliveryMethod; }

    @Override
    public String toString() {
        return "Order{id=" + orderId + ", date=" + orderDate + ", customer=" + customerId + ", total=$" + String.format("%.2f", total) + "}";
    }
}

