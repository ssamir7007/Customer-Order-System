/**
 * Represents a product in the catalog.
 */
public class Product {
    private String id;
    private String name;
    private String description;
    private double price;
    private Double salePrice; // nullable; if present use salePrice

    public Product(String id, String name, String description, double price, Double salePrice) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.salePrice = salePrice;
    }

    public double getEffectivePrice() {
        return (salePrice != null) ? salePrice : price;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public Double getSalePrice() { return salePrice; }

    @Override
    public String toString() {
        return id + " - " + name + " ($" + String.format("%.2f", getEffectivePrice()) + ")";
    }
}

